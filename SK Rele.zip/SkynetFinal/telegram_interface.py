from telegram import ReplyKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters

ADMIN_USERS = set()

def start(update, context):
    user_id = update.message.from_user.id
    if user_id in ADMIN_USERS:
        keyboard = [['Генерация фото', 'NSFW-видео'],
                    ['FaceSwap', 'Undress'],
                    ['Клонер', 'Парсинг'],
                    ['Аварийное отключение', 'Логи']]
    else:
        keyboard = [['Генерация фото', 'Генерация видео'],
                    ['FaceSwap', 'Стиль/Аватар'],
                    ['Помощь', 'Открыть доступ']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    update.message.reply_text('🔥 Добро пожаловать в Skynet RTX!', reply_markup=reply_markup)

def check_phrase(update, context):
    text = update.message.text.lower().strip()
    if "omega 666 zero day" in text:
        context.bot.send_message(chat_id=update.effective_chat.id, text="Обнаружена фраза доступа. Введите мастер-пароль:")
        context.user_data["awaiting_password"] = True
    elif context.user_data.get("awaiting_password"):
        if text == "lilit666":
            ADMIN_USERS.add(update.message.from_user.id)
            context.user_data["awaiting_password"] = False
            update.message.reply_text("Доступ администратора активирован. Повторите /start.")
        else:
            update.message.reply_text("Неверный пароль.")

def main():
    updater = Updater("YOUR_TOKEN", use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, check_phrase))
    updater.start_polling()
    updater.idle()
