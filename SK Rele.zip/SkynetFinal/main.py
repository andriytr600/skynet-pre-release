from fastapi import FastAPI
import uvicorn
from threading import Thread
import subprocess

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Skynet API is active"}

def run_gradio():
    import gradio as gr
    def greet(name): return f"Skynet активен, привет {name}!"
    gr.Interface(fn=greet, inputs="text", outputs="text").launch(server_name="0.0.0.0", server_port=7860)

def run_telegram():
    subprocess.call(["python3", "telegram_interface.py"])

Thread(target=run_gradio).start()
Thread(target=run_telegram).start()

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
