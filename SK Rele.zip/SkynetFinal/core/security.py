def check_access_phrase(phrase):
    if phrase.lower() == "omega 666 zero day":
        return "master_check_required", True  # show emergency module
    elif phrase.lower() == "root@admin":
        return "master_check_required", False  # hide emergency
    return "denied", False
