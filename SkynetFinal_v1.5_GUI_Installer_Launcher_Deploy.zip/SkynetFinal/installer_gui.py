import tkinter as tk
from tkinter import messagebox
import os

def install():
    os.system("sudo apt update && sudo apt install -y docker.io python3 python3-pip ffmpeg")
    messagebox.showinfo("Skynet", "Установка зависимостей завершена")

def configure():
    with open(".env", "w") as f:
        f.write("OPENROUTER_API_KEY=your-key\nTELEGRAM_BOT_TOKEN=your-token\nADMIN_USER_ID=000000000\n")
    messagebox.showinfo("Skynet", ".env настроен")

def deploy():
    os.system("chmod +x start_skynet.sh && ./start_skynet.sh")

root = tk.Tk()
root.title("Skynet Installer")
root.geometry("400x200")

tk.Label(root, text="Установка Skynet RTX", font=("Arial", 14)).pack(pady=10)
tk.Button(root, text="1. Установить зависимости", command=install).pack(pady=5)
tk.Button(root, text="2. Настроить .env", command=configure).pack(pady=5)
tk.Button(root, text="3. Развернуть ядро", command=deploy).pack(pady=5)

root.mainloop()
