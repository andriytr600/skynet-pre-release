from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
from telegram import ReplyKeyboardMarkup
import os

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")

users_in_admin_mode = set()

def start(update, context):
    keyboard = [["Генерация фото", "Генерация видео"],
                ["FaceSwap", "Undress"],
                ["Админ-панель"]]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    update.message.reply_text("🔥 Добро пожаловать в Skynet RTX!
Выбери действие:", reply_markup=reply_markup)

def handle_message(update, context):
    msg = update.message.text.lower()
    user_id = update.message.from_user.id

    if msg == "omega 666 zero day":
        context.bot.send_message(chat_id=update.effective_chat.id, text="Введите мастер-пароль:")
        users_in_admin_mode.add(user_id)
    elif msg == "lilit666" and user_id in users_in_admin_mode:
        context.bot.send_message(chat_id=update.effective_chat.id, text="Админ-панель активирована.")
        users_in_admin_mode.remove(user_id)
    elif msg == "root@admin":
        context.bot.send_message(chat_id=update.effective_chat.id, text="Вход в админку разрешён, но скрыт.")
    else:
        context.bot.send_message(chat_id=update.effective_chat.id, text="Команда получена: " + update.message.text)

updater = Updater(TOKEN, use_context=True)
dp = updater.dispatcher
dp.add_handler(CommandHandler("start", start))
dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))

updater.start_polling()
updater.idle()
