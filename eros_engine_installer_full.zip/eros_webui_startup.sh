
#!/bin/bash

echo ">>> [Eros Engine RTX] Запуск WebUI..."

# Активируем окружение
source ~/eros_engine/venv/bin/activate

# Запускаем WebUI (AUTOMATIC1111 или другой интерфейс)
cd ~/eros_engine/webui
nohup python3 launch.py --xformers --listen --port 7860 > ~/eros_engine/logs/webui.log 2>&1 &

echo "✅ WebUI запущен на порту 7860."
