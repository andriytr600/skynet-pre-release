
#!/bin/bash

# Установка необходимых зависимостей
echo "Установка зависимостей..."
sudo apt-get update
sudo apt-get install -y python3.10 python3.10-venv python3-pip git ffmpeg wget curl

# Клонирование репозитория Eros Engine
echo "Клонирование Eros Engine..."
git clone https://github.com/YourRepository/eros_engine.git ~/eros_engine

# Создание и активация виртуального окружения
echo "Создание виртуального окружения..."
python3.10 -m venv ~/eros_engine/venv
source ~/eros_engine/venv/bin/activate

# Установка зависимостей Python
echo "Установка зависимостей..."
pip install -r ~/eros_engine/requirements_updated.txt

# Запуск стартапа
echo "Запуск Eros Engine..."
bash ~/eros_engine/eros_engine_startup.sh
