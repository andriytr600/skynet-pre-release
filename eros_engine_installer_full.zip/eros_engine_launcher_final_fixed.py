
import subprocess
import sys
import os
import telebot

# Ensure required dependencies are installed
try:
    import telebot  # Проверка наличия библиотеки для бота
except ImportError:
    print("Не найдены необходимые зависимости. Выполняется установка...")
    subprocess.run([sys.executable, "eros_engine_final_installer_final_corrected.py"], check=True)

# Запуск Eros Engine RTX (заглушка для реального запуска)
print("Запуск Eros Engine RTX...")
# TODO: Здесь можно вставить команды для реального запуска основного приложения
# subprocess.Popen([sys.executable, "eros_engine_main.py"])

print("Eros Engine RTX успешно запущен.")
