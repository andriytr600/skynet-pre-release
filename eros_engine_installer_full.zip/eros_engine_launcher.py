
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import time
import subprocess
import telebot
import psutil
from datetime import datetime, timedelta

LOCK_FILE = os.path.expanduser("~/.eros_engine/install.lock")
PROGRESS_FILE = os.path.expanduser("~/.eros_engine/progress.json")
TELEGRAM_TOKEN = "8093963383:AAEU_HsVmhRdSE0kK6wGtF7W5yOgHhxUnvI"
TELEGRAM_USER_ID = 5379133284
bot = telebot.TeleBot(TELEGRAM_TOKEN, parse_mode="Markdown")

steps = [
    ("Подготовка системы", "sudo apt update && sudo apt install -y python3.10 python3.10-venv python3-pip git ffmpeg wget curl"),
    ("Создание каталогов", "mkdir -p ~/eros_engine/{models,outputs,webui,llm,ai,logs} ~/.eros_engine"),
    ("Создание venv", "python3.10 -m venv ~/eros_engine/venv"),
    ("Активация venv", "source ~/eros_engine/venv/bin/activate && pip install --upgrade pip setuptools"),
    ("Установка PyTorch", "source ~/eros_engine/venv/bin/activate && pip install torch==2.6.0 torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124"),
    ("Клонирование WebUI", "git clone https://github.com/AUTOMATIC1111/stable-diffusion-webui ~/eros_engine/webui"),
    ("Установка зависимостей WebUI", "cd ~/eros_engine/webui && pip install -r requirements_versions.txt"),
    ("Скачивание модели LLM", "mkdir -p ~/eros_engine/llm/models && cd ~/eros_engine/llm/models && wget -O OpenHermes-2.5-Mistral.Q4_K_M.gguf https://huggingface.co/TheBloke/OpenHermes-2.5-Mistral-GGUF/resolve/main/openhermes-2.5-mistral.Q4_K_M.gguf"),
    ("Сборка llama.cpp", "git clone https://github.com/ggerganov/llama.cpp ~/eros_engine/ai/llama.cpp && cd ~/eros_engine/ai/llama.cpp && make -j$(nproc)"),
    ("Финальный запуск системы", "bash ~/eros_engine/eros_startup.sh")
]

def load_progress():
    if not os.path.exists(PROGRESS_FILE):
        return 0
    with open(PROGRESS_FILE, "r") as f:
        return json.load(f).get("last_step", 0)

def save_progress(step_index):
    with open(PROGRESS_FILE, "w") as f:
        json.dump({"last_step": step_index}, f)

def is_already_running():
    if os.path.exists(LOCK_FILE):
        with open(LOCK_FILE, "r") as f:
            pid = int(f.read().strip())
            if psutil.pid_exists(pid):
                return True
    return False

def set_lock():
    with open(LOCK_FILE, "w") as f:
        f.write(str(os.getpid()))

def clear_lock():
    if os.path.exists(LOCK_FILE):
        os.remove(LOCK_FILE)

def send_status(stage, index, total, start_time, durations):
    percent = int((index + 1) / total * 100)
    bar = "█" * int(percent / 5) + "░" * (20 - int(percent / 5))
    now = datetime.now()
    elapsed = now - start_time
    avg_time = sum(durations, timedelta()) / len(durations) if durations else timedelta(seconds=30)
    remaining = avg_time * (total - (index + 1))
    msg = (
        f"*{stage}*
"
        f"`{bar}  {percent}%`
"
        f"⏱ Начато: {start_time.strftime('%H:%M:%S')}
"
        f"⏳ Выполняется: {str(elapsed).split('.')[0]}
"
        f"⌛️ Осталось примерно: {str(remaining).split('.')[0]}"
    )
    bot.send_message(TELEGRAM_USER_ID, msg)

def main():
    if is_already_running():
        print("Установка уже выполняется.")
        sys.exit(0)

    set_lock()
    last_step = load_progress()
    durations = []

    for i, (name, command) in enumerate(steps[last_step:], start=last_step):
        start_time = datetime.now()
        send_status(name, i, len(steps), start_time, durations)

        if command:
            code = subprocess.call(command, shell=True)
            if code != 0:
                bot.send_message(TELEGRAM_USER_ID, f"❌ Ошибка на этапе: {name}")
                clear_lock()
                sys.exit(1)

        durations.append(datetime.now() - start_time)
        save_progress(i + 1)
        time.sleep(1)

    bot.send_message(TELEGRAM_USER_ID, "✅ Установка Eros Engine RTX завершена. Все процессы запущены.")
    clear_lock()

if __name__ == "__main__":
    main()
