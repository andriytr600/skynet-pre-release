
import json
import sys
import subprocess
import shutil
import urllib.request
import os

plan_file = "install_recovery_plan_updated.json"

# Load installation plan
with open(plan_file, 'r', encoding='utf-8') as f:
    plan = json.load(f)

recover_mode = "--recover" in sys.argv

# If everything is already done, exit (nothing to do)
if plan.get("steps") and all(step.get("done") for step in plan["steps"]):
    print("Все шаги установки уже выполнены ранее.")
    sys.exit(0)

# If fresh install mode, reset progress flags
if not recover_mode:
    for step in plan.get("steps", []):
        step["done"] = False
    with open(plan_file, 'w', encoding='utf-8') as f:
        json.dump(plan, f, indent=4, ensure_ascii=False)

steps = plan.get("steps", plan)
for step in steps:
    # In recovery mode, skip already completed steps
    if recover_mode and step.get("done"):
        continue

    action = step.get("action") or step.get("type") or step.get("name")
    if not action:
        print(f"Некорректная структура шага: {step}. Пропуск.")
        continue

    try:
        if action == "pip_install":
            req_file = step.get("target") or step.get("requirements_file") or "requirements_updated.txt"
            print(f"Установка Python-зависимостей из {req_file}...")
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", req_file], check=True)
        elif action == "copy":
            src = step.get("src"); dest = step.get("dest")
            if src and dest:
                print(f"Копирование {src} -> {dest}...")
                shutil.copy(src, dest)
            else:
                print(f"Пропущен шаг копирования, отсутствуют пути: {step}")
        elif action == "download":
            url = step.get("url"); dest = step.get("dest")
            if url and dest:
                print(f"Загрузка из {url} в {dest}...")
                urllib.request.urlretrieve(url, dest)
            else:
                print(f"Пропущен шаг загрузки, отсутствует URL или путь назначения: {step}")
        elif action == "extract":
            archive = step.get("file") or step.get("archive")
            dest_dir = step.get("dest") or step.get("directory")
            if archive and dest_dir:
                print(f"Распаковка {archive} в {dest_dir}...")
                import zipfile
                with zipfile.ZipFile(archive, 'r') as zip_ref:
                    zip_ref.extractall(dest_dir)
            else:
                print(f"Пропущен шаг распаковки, отсутствуют параметры: {step}")
        else:
            cmd = step.get("command")
            if cmd:
                print(f"Выполнение команды: {cmd}...")
                subprocess.run(cmd, shell=True, check=True)
            else:
                print(f"Неизвестное действие '{action}' в шаге: {step}")

        # Mark step as completed
        step["done"] = True
        with open(plan_file, 'w', encoding='utf-8') as f:
            json.dump(plan, f, indent=4, ensure_ascii=False)

    except Exception as e:
        print(f"Ошибка на шаге '{step.get('name', action)}': {e}")
        print("Прерывание установки. Для восстановления выполните скрипт с параметром --recover.")
        sys.exit(1)

print("Все шаги установки выполнены успешно.")
