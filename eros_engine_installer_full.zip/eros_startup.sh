
#!/bin/bash

echo ">>> [Eros Engine RTX] Автозапуск компонентов..."

# Активируем окружение
source ~/eros_engine/venv/bin/activate

# Запускаем Telegram-бота в фоне
echo "[+] Запуск Telegram-бота..."
nohup python3 ~/eros_engine/start_eros_bot.py > ~/eros_engine/logs/bot.log 2>&1 &

# Запускаем WebUI AUTOMATIC1111
echo "[+] Запуск WebUI (порт 7860)..."
cd ~/eros_engine/webui
nohup python3 launch.py --xformers --listen --port 7860 > ~/eros_engine/logs/webui.log 2>&1 &

echo "✅ Все процессы запущены."
