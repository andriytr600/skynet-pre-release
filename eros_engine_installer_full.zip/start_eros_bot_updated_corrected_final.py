
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackContext
import subprocess
import os
import threading

TOKEN = "8093963383:AAEU_HsVmhRdSE0kK6wGtF7W5yOgHhxUnvI"
USER_ID = 5379133284

LLM_PATH = os.path.expanduser("~/eros_engine/llm/models/OpenHermes-2.5-Mistral.Q4_K_M.gguf")
LLAMA_BIN = os.path.expanduser("~/eros_engine/ai/llama.cpp/main")

async def start(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text("Добро пожаловать в *Eros Engine RTX*.
Готов к вашим командам.")

async def llm(update: Update, context: CallbackContext) -> None:
    prompt = ' '.join(context.args)
    if not prompt:
        await update.message.reply_text("Введите запрос после команды /llm")
        return
    await update.message.reply_text("Генерирую ответ...")
    response = subprocess.check_output([LLAMA_BIN, "-m", LLM_PATH, "-p", prompt, "-n", "400"]).decode()
    await update.message.reply_text(response[:4000])

async def torch_status(update: Update, context: CallbackContext) -> None:
    try:
        import torch
        cuda = torch.cuda.is_available()
        version = torch.__version__
        cuda_version = torch.version.cuda
        gpus = torch.cuda.device_count()
        msg = f"PyTorch: `{version}`
CUDA доступна: `{cuda}`
Версия CUDA: `{cuda_version}`
GPU: `{gpus}`"
    except Exception as e:
        msg = f"Ошибка: {str(e)}"
    await update.message.reply_text(msg)

async def system_check(update: Update, context: CallbackContext) -> None:
    try:
        import torch, platform, psutil
        sysinfo = (
            "*Состояние системы:*
"
            f"*Python:* `{platform.python_version()}`
"
            f"*Torch:* `{torch.__version__}`
"
            f"*CUDA:* `{torch.version.cuda}`
"
            f"*CUDA активна:* `{torch.cuda.is_available()}`
"
            f"*GPU:* `{torch.cuda.device_count()}`
"
            f"*CPU:* `{psutil.cpu_count(logical=True)}`
"
            f"*RAM:* `{round(psutil.virtual_memory().total/1024/1024/1024, 1)} ГБ`"
        )
        await update.message.reply_text(sysinfo)
    except Exception as e:
        await update.message.reply_text(f"Ошибка проверки: {str(e)}")

def main() -> None:
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("llm", llm))
    application.add_handler(CommandHandler("torch_status", torch_status))
    application.add_handler(CommandHandler("system_check", system_check))

    application.run_polling()

if __name__ == "__main__":
    main()
