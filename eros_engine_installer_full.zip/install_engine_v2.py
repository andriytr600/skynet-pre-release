
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import time
import telebot
import threading

# === НАСТРОЙКИ ===
TELEGRAM_TOKEN = "8093963383:AAEU_HsVmhRdSE0kK6wGtF7W5yOgHhxUnvI"
TELEGRAM_USER_ID = 5379133284

# === БОТ ДЛЯ УСТАНОВКИ ===
bot = telebot.TeleBot(TELEGRAM_TOKEN, parse_mode="Markdown")

def send_stage(stage_name, percent):
    bar = int(percent / 5)
    bar_str = "█" * bar + "░" * (20 - bar)
    msg = f"*{stage_name}*
`{bar_str}  {percent}%`"
    bot.send_message(TELEGRAM_USER_ID, msg)

def send_message(text):
    bot.send_message(TELEGRAM_USER_ID, f"`{text}`")

def simulate_installation():
    steps = [
        ("Подготовка системы", 10),
        ("Установка Python-зависимостей", 20),
        ("Сборка моделей", 30),
        ("Загрузка SDXL", 40),
        ("Настройка WebUI", 55),
        ("Установка LLM", 70),
        ("Интеграция бота", 85),
        ("Финализация", 100)
    ]
    for name, percent in steps:
        send_stage(name, percent)
        time.sleep(2)
    send_message("✅ Установка завершена. Запускаю основного бота...")

def run_telegram():
    try:
        bot.polling(none_stop=True)
    except:
        time.sleep(5)
        run_telegram()

def main():
    threading.Thread(target=run_telegram, daemon=True).start()
    simulate_installation()

if __name__ == "__main__":
    main()
