# Skynet RTX — Инструкция по запуску

## Состав:
- Telegram-интерфейс
- Gradio Web UI (порт 7860)
- REST API (порт 8000)
- Полная поддержка CUDA, RTX, DLSS
- NSFW-модули, face swap, undress, видео до 30 мин
- Многопоточность и автоопределение ресурсов
- Модуль Telegram-бота, парсинг, клонеры
- Возможность будущей интеграции с приложениями по API

## Запуск:

1. Распакуй архив:
```
unzip SkynetFinal_Full_Docker_and_API.zip
cd SkynetFinal
```

2. Укажи ключи в `.env`:
```
OPENROUTER_API_KEY=...
TELEGRAM_BOT_TOKEN=...
ADMIN_USER_ID=...
```

3. Запусти систему:
```
chmod +x start_skynet.sh
./start_skynet.sh
```

## Доступ:

- **Gradio-интерфейс (UI):** http://localhost:7860
- **REST API:** http://localhost:8000
- **Telegram:** бот работает в фоне (указан в .env)

## Админ-доступ:

1. Введи в Telegram:
```
Lilit666
```

2. Доступ к NSFW, undress, генерации видео, клонированию ботов и парсингу чатов будет разблокирован.

## Веб и Telegram работают параллельно.
