import os
from dotenv import load_dotenv
import torch
import multiprocessing
import psutil

load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ADMIN_USER_ID = int(os.getenv("ADMIN_USER_ID", "0"))

def auto_detect_performance():
    cpu_cores = multiprocessing.cpu_count()
    ram_total = psutil.virtual_memory().total / (1024 ** 3)
    gpu_count = torch.cuda.device_count()
    gpu_mem = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3) if gpu_count > 0 else 0

    if gpu_count >= 2 and gpu_mem >= 20 and cpu_cores >= 8:
        return {
            "mode": "multi-thread",
            "max_threads": cpu_cores,
            "gpu": "enabled"
        }
    else:
        return {
            "mode": "single-thread",
            "max_threads": 1,
            "gpu": "fallback" if gpu_count else "none"
        }

SYSTEM_MODE = auto_detect_performance()
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

print(f"[Skynet] Режим: {SYSTEM_MODE['mode'].upper()}, Потоки: {SYSTEM_MODE['max_threads']}, GPU: {SYSTEM_MODE['gpu']}")
print(f"[Skynet] Используется устройство: {DEVICE.upper()}")
