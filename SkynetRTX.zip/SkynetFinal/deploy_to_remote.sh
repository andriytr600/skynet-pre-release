#!/bin/bash
# Авторазвёртывание Skynet на удалённый сервер
REMOTE_USER=$1
REMOTE_IP=$2
REMOTE_PATH="/home/$REMOTE_USER/skynet_remote"

echo "[Skynet] Копирую файлы на $REMOTE_IP..."
scp -r . $REMOTE_USER@$REMOTE_IP:$REMOTE_PATH

echo "[Skynet] Установка и запуск..."
ssh $REMOTE_USER@$REMOTE_IP "cd $REMOTE_PATH && chmod +x start_skynet.sh && ./start_skynet.sh"
