import tkinter as tk
import webbrowser
import os

def launch_gradio(): webbrowser.open("http://localhost:7860")
def launch_api(): webbrowser.open("http://localhost:8000")
def launch_telegram(): os.system("python3 telegram_interface.py")
def open_logs(): os.system("less logs/skynet.log")

root = tk.Tk()
root.title("Skynet Launcher")
root.geometry("400x220")

tk.Label(root, text="Skynet RTX Launcher", font=("Arial", 14)).pack(pady=10)
tk.Button(root, text="Открыть Web-интерфейс", command=launch_gradio).pack(pady=5)
tk.Button(root, text="Открыть REST API", command=launch_api).pack(pady=5)
tk.Button(root, text="Запустить Telegram-бота", command=launch_telegram).pack(pady=5)
tk.Button(root, text="Показать логи", command=open_logs).pack(pady=5)

root.mainloop()
