#!/bin/bash
echo "[Skynet] Запуск системы..."
docker-compose down
docker-compose up --build -d
