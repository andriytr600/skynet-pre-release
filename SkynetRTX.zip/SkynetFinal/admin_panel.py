def open_admin_panel(emergency=False):
    print(":: SKNET ADMIN PANEL ::")
    print("Настройки, режимы, доступы...")
    if emergency:
        print("!!! АКТИВНА КНОПКА АВАРИЙНОГО ОТКЛЮЧЕНИЯ !!!")
    else:
        print("(Аварийная кнопка скрыта в этом режиме)")
